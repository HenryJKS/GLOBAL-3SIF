package br.com.fiap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fiap.model.Cultivo;

public interface CultivoRepository extends JpaRepository<Cultivo, Long>{

}
