package br.com.fiap.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.fiap.model.Cultivo;
import br.com.fiap.repository.CultivoRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;



@RestController
@Tag(name = "API de Cultivos", description = "A API mostra os cultivos de uma plantações através de API")
@RequestMapping("/api/cultivos")
public class CultivoController {
	
	@Autowired
	private CultivoRepository repository;
	
	@GetMapping
	@Operation(summary="Exibe todos os cultivos")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Cultivos encontrado com sucesso"),
			@ApiResponse(responseCode = "404", description = "Não foi possível encontrar os cultivos!"),
			@ApiResponse(responseCode = "500", description = "Erro interno no servidor")
	})
	@ResponseStatus(HttpStatus.OK)
	public List<Cultivo> index(){
		return repository.findAll();
	}
	
	@PostMapping
	@Operation(summary = "Cria um novo cultivo")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Cultivo criado com sucesso!!"),
			@ApiResponse(responseCode = "400", description = "Parâmetros insuficientes, insira todos os paramêtros"),
			@ApiResponse(responseCode = "500", description = "Erro interno no servidor")
	})
	public ResponseEntity<String> create(@RequestBody Cultivo cultivosRequest) {
		try {
			if (cultivosRequest.getNome() == null || cultivosRequest.getPeriodoColheita() == null
					|| cultivosRequest.getPeriodoPlantio() == null || cultivosRequest.getTipoClimaNecessario() == null
					|| cultivosRequest.getTipoSoloNecessario() == null || cultivosRequest.getValorMercado() == 0) {
				System.out.println("====ERROR=====");
				System.out.println("Inira todos os parâmetros");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
			}

			Cultivo cultivo = new Cultivo();
			cultivo.setNome(cultivosRequest.getNome());
			cultivo.setPeriodoColheita(cultivosRequest.getPeriodoColheita());
			cultivo.setPeriodoPlantio(cultivosRequest.getPeriodoPlantio());
			cultivo.setTipoClimaNecessario(cultivosRequest.getTipoClimaNecessario());
			cultivo.setTipoSoloNecessario(cultivosRequest.getTipoSoloNecessario());
			cultivo.setValorMercado(cultivosRequest.getValorMercado());

			repository.save(cultivo);

			return ResponseEntity.status(HttpStatus.CREATED).build();
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
	

	@GetMapping("{id}")
	@Operation(summary = "Exibe um cultivo pelo id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Cultivo encontrado com sucesso!!"),
			@ApiResponse(responseCode = "404", description = "Cultivo não encontrado, verifique se está passando o id correto"),
			@ApiResponse(responseCode = "500", description = "Erro interno no servidor")
	})
	public ResponseEntity<Cultivo> show(@PathVariable("id") long id) {

		Optional<Cultivo> cultivo = repository.findById(id);

		if (cultivo.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}

		return ResponseEntity.ok(cultivo.get());
	}
	
	@PutMapping("{id}")
	@Operation(summary = "Atualiza cultivo pelo id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Cultivo aualizado com sucesso!!"),
			@ApiResponse(responseCode = "404", description = "Cultivo não encontrado, verifique se está passando o id correto"),
			@ApiResponse(responseCode = "500", description = "Erro interno no servidor")
	})
	public ResponseEntity<String> update(@PathVariable("id") long id, @RequestBody Cultivo cultivosRequest) {
		try {
			if (repository.findById(id).isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}

			Cultivo cultivo = new Cultivo();
			cultivo.setId(id);
			cultivo.setNome(cultivosRequest.getNome());
			cultivo.setPeriodoColheita(cultivosRequest.getPeriodoColheita());
			cultivo.setPeriodoPlantio(cultivosRequest.getPeriodoPlantio());
			cultivo.setTipoClimaNecessario(cultivosRequest.getTipoClimaNecessario());
			cultivo.setTipoSoloNecessario(cultivosRequest.getTipoSoloNecessario());
			cultivo.setValorMercado(cultivosRequest.getValorMercado());

			repository.save(cultivo);

			return ResponseEntity.ok("Cultivo atualizado com sucesso!!");
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
	
	@DeleteMapping("{id}")
	@Operation(summary = "Exclui cultivo pelo id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "204", description = "Cultivo excluído com sucesso!!"),
			@ApiResponse(responseCode = "404", description = "Cultivo não encontrado, verifique se está passando o id correto"),
			@ApiResponse(responseCode = "500", description = "Erro interno no servidor")
	})
	public ResponseEntity<String> destroy(@PathVariable("id") long id) {
		try {
			if (repository.findById(id).isEmpty()) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
			
			Cultivo cultivo = repository.findById(id).get();
			
			repository.delete(cultivo);

			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
	
	

}
