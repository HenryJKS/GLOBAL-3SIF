package br.com.fiap.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="TB_CULTIVOS")
public class Cultivo {
	

	@Id 
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CULTIVO_SEQ")
	@SequenceGenerator(name = "CULTIVO_SEQ", sequenceName = "CULTIVO_SEQ", allocationSize = 1)
	private long id;
	
	private String nome;
	private String tipoSoloNecessario;
	private String tipoClimaNecessario;
	private String periodoPlantio;
	private String periodoColheita;
	private double valorMercado;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTipoSoloNecessario() {
		return tipoSoloNecessario;
	}
	public void setTipoSoloNecessario(String tipoSoloNecessario) {
		this.tipoSoloNecessario = tipoSoloNecessario;
	}
	public String getTipoClimaNecessario() {
		return tipoClimaNecessario;
	}
	public void setTipoClimaNecessario(String tipoClimaNecessario) {
		this.tipoClimaNecessario = tipoClimaNecessario;
	}
	public String getPeriodoPlantio() {
		return periodoPlantio;
	}
	public void setPeriodoPlantio(String periodoPlantio) {
		this.periodoPlantio = periodoPlantio;
	}
	public String getPeriodoColheita() {
		return periodoColheita;
	}
	public void setPeriodoColheita(String periodoColheita) {
		this.periodoColheita = periodoColheita;
	}
	public double getValorMercado() {
		return valorMercado;
	}
	public void setValorMercado(double valorMercado) {
		this.valorMercado = valorMercado;
	}
	
	
	
	
}
